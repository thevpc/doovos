swan using @newterm @nowait
